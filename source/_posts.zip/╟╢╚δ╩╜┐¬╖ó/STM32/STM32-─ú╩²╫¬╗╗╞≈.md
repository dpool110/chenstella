---
title: STM32-模数转换器
tags:
  - 嵌入式开发
  - STM32
categories: STM32
cover: 'https://raw.githubusercontent.com/dpool110/picgo/master/202212241439122.png'
abbrlink: e71e9caf
date: 2023-01-04 10:00:48
---

# STM32-模数转换器

在市面上有很多传感器，可以分为数字型和模拟型的传感器。DHT11数字型传感器采集到的就是数字两，可以直接交给cpu处理，模拟型传感器，采集到的是模拟量，需要经过模数转换（AD）之后给cpu进行处理。
