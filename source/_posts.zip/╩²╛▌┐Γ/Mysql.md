---
title: Mysql
categories: 编程开发学习
tags:
  - MySQL数据库
cover: 'https://i.loli.net/2021/09/18/U9eJSvxbL7AaCZi.jpg'
abbrlink: 62688
date: 2021-05-20 15:58:34
---



# MySQL

## 1、初始数据库

### 1.1、安装MySQL

1. 下载压缩包

2. 解压到自己想要安装的目录

3. 添加环境变量

   1. 我的电脑—属性—高级—环境变量

   2. 选择PATH，在后面添加mysql安装文件下的bin文件夹

   3. 在bin当前目录新建my.ini文件

   4. 编辑my.ini注意替换路径位置

      ```mysql
      [mysql]
      #目录一定换成自己的
      basedir=E:\mysql\mysql-5.7.23\
      datadir=E:\mysql\mysql-5.7.23\data\
      port=3306
      skip-grant-tables
      ```

   5. 管理员模式启动cmd，并将路径切换至mysql下的bin目录，然后输入mysqld -install

      > 重新安装mysql可能会出现数据库已经存在并报错此时使用 `mysqld remove` 然后再执行 `mysqld -install` 即可

   6. 再输入`mysqld --initialize-insecure --user=mysql`初始化数据文件

   7. 然后再启动mysql 用命令`mysql -u root -p`进入mysql管理界面（密码可为空）

   8. 进入界面后更改root密码（sql语句后面一定要加分号）

      ```mysql
      updata mysql,user set authentication_string=password('123456') where user='root' and Host='localhost';
      ```

      最后输入flush privileges;刷新权限

   9. 修改my.ini文件删除最后一句skip-grant-atbles

   10. 重启mysql即可使用

       ```mysql
       net satrt mysql #启动数据库
       net stop mysql #停止数据库
       sc delete mysql #清空服务（安装出错时执行）
       ```

       

   11. 注释掉my.ini中最后一行，重启mysql，测试连接



### 1.2、连接数据库

命令行连接

````mysql
mysql -uroot -p123456 --连接数据库

update mysql.user set authentication_string=password('123456') where user='root' and Host='localhost'；--修改用户密码
flush privileges; --刷新权限
````

