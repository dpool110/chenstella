---
title: SpringCloud——服务熔断
categories: 编程开发学习
tags:
  - Java
  - SrpingBoot
conver: 'https://s2.loli.net/2022/03/01/EQFS7h3Ud5ZpwxI.jpg'
hide: true
abbrlink: 17083
date: 2022-02-25 19:27:37
---

## 前言

