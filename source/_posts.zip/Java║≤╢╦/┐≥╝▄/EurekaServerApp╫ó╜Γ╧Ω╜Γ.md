---
title: EurekaServerApp注解详解
categories: Java
tags:
  - Java
  - SpringCloud
abbrlink: 60158
date: 2022-03-07 22:25:35
---

# EurekaServerApp注解详解

> EurekaServerApp中有@SpringBootApplication和@EnableEurekaServer两个注解，简单来说@SpringBootApplication的作用就是表明一个类为spring boot的启动类

​	
